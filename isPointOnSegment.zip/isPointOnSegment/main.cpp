#include <iostream>

const int VERTICAL = 1;
const int SLANTED = 0;
const int HORIZONTAL = 2;
const int POINT = 3;

const double EPSILON = .001;


const int GREATER_THAN = 1;
const int EQUAL = 0;
const int LESS_THAN = -1;

int compare_doubles(double a, double b) {
    if(a - b > EPSILON) {
        // std::cout << a << " is greater than " << b << std::endl;
        return GREATER_THAN;
    }
    if(b-a >EPSILON) {
        // std::cout << a << " is less than " << b << std::endl;
        return LESS_THAN;
    }
    return EQUAL;
}

int getFuncFromSegment(double x1, double y1, double x2, double y2, double* a, double *b) {
    //double x1, double y1, double x2, double y2 are the points of the segments
    // a and b are the ax + b = y constants for the function
    bool same_x = compare_doubles(x1, x2)==EQUAL;
    bool same_y = compare_doubles(y1, y2)==EQUAL;

    if(same_x && same_y)return POINT;
    if(same_x) {
        return VERTICAL;
    }
    if(same_y)
        return HORIZONTAL;


    if(compare_doubles(x1, 0)!=EQUAL) {
        *b = (y1*x2 - y2*x1)/(x2-x1);
        *a = (y1 - *b)/x1;
    }
    else if(compare_doubles(x2, 0)!=EQUAL) {
        *b = (y1*x2 - y2*x1)/(x2-x1);
        *a = (y2 - *b)/x2;
    }
    else return POINT;
    return SLANTED;
}


bool isPointOnSegment(double x1, double y1, double x2, double y2, double point_x, double point_y) {
    double a, b;
    int type_of_line = getFuncFromSegment(x1, y1, x2, y2, &a, &b);
    if(type_of_line == POINT) {
        if(compare_doubles(point_x, x1) == EQUAL &&
            compare_doubles(y1, y2) == EQUAL)
            return true;
        else return false;
    }
    else if(type_of_line == VERTICAL) {
        // std::cout << compare_doubles(y1, y2)<< std::endl;
        double bigger_y = ((compare_doubles(y1, y2) == GREATER_THAN)?y1:y2);
        double smaller_y = ((y1 == bigger_y)?y2:y1);
        if(compare_doubles(point_y, smaller_y) >= EQUAL &&
            compare_doubles(point_y, bigger_y) >= EQUAL)return true;
        else return false;
    }
    else if(type_of_line == HORIZONTAL) {
        double bigger_x = ((compare_doubles(x1, x2) == GREATER_THAN)?x1:x2);
        double smaller_x = ((x1 == bigger_x)?x2:x1);
        if(compare_doubles(point_x, smaller_x) >= EQUAL &&
            compare_doubles(point_x, bigger_x) <= EQUAL)return true;
        else return false;
    }
    else if(type_of_line == SLANTED) {
        if(compare_doubles(a*point_x + b, point_y) == EQUAL)
            return true;
        else return false;
    }
    return false;
}

int main() {
    double a, b;
    std::cout<<isPointOnSegment(0, 0, 3, 3, 2, 3) << std::endl;
    return 0;
}
