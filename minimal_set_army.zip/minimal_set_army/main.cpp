#include <iostream>

int army[1000000], battles[1000], index_pow_map[1000000];

int find_most_optimal(int min_pow, int k) {
    int ind=-1, minpow=20000001;
    for(int i=0;i<k;i++) {
        if(index_pow_map[i]==min_pow)
            return i;
        if(index_pow_map[i]<minpow && index_pow_map[i]>min_pow) {
            ind = i;
            minpow = index_pow_map[i];
        }
    }
    return ind;
}

int main() {
    int n,k,b;
    std::cin >> n >> k >> b;

    for(int i=0;i<n;i++) {
        std::cin >> army[i];
    }
    for(int i=0;i<b;i++) {
        std::cin>>battles[i];
    }

    int first_map_pow = 0;
    for(int i =0; i<k;i++)
        first_map_pow += army[i];
    index_pow_map[0]=first_map_pow;
    for(int i=1; i<n-k+1; i++) {
        index_pow_map[i] = index_pow_map[i-1] - army[i-1] + army[i+k-1];
    }
// to make it more optimal for really large values i can use an ordered map with key and val
    for(int i=0;i<b;i++) {
        std::cout << find_most_optimal(battles[i], n-k+1)  <<std::endl;
    }

    return 0;
}
