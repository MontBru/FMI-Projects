#include <iostream>

int main() {
    char a = 'A', b = 'B';
    a=a^b;
    b=a^b;
    a=a^b;

    std::cout << "a: " << a << std::endl << "b: " << b << std::endl;
    return 0;
}
