#include <iostream>


int find_weaker(int pow, int *legionaires, int n) {
    int weaker_cnt = 0;
    bool isLegionaireWithPow = false;
    for(int i=0; i<n; i++) {
        if(legionaires[i]==pow)
            isLegionaireWithPow=true;
        if(legionaires[i]<pow)
            weaker_cnt++;
    }
    if(isLegionaireWithPow)
        return weaker_cnt;
    else
        return -1;
}

int main() {
    int n=0;
    std::cin >> n;
    int *legionaires = new int[n];
    for(int i = 0; i<n; i++) {
        std::cin >> legionaires[i];
    }
    int pow = 0;
    while(true) {
        std::cin >> pow;
        if(pow == 0)
            break;
        std::cout << find_weaker(pow, legionaires, n) << std::endl;
    }

    delete legionaires;
    return 0;
}
