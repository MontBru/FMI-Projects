#include <iostream>

bool bit_i(int a, int i) {
    return !((a>>(i-1))%2);
}

int main()
{
    char a = 5;
    std::cout << bit_i(a,0) << std::endl;
    std::cout << bit_i(a,1) << std::endl;
    std::cout << bit_i(a,2) << std::endl;
    return 0;
}
