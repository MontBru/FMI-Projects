#include <cstring>
#include <iostream>

int num_len(int n) {
    int len = 0;
    if(n==0)return 1;
    while (n > 0) {
        len++;
        n/=10;
    }
}

bool hasDublingDigits(int n) {
    int num_l = num_len(n);
    int *arr = new int[num_l];
    int i=0;
    while(n>0) {
        int digit = n%10;
        arr[i]=digit;

        for(int j=0; j<i; j++) {
            if(arr[j]==digit) {
                delete arr;
                return true;
            }

        }

        i++;
        n/=10;
    }
    delete arr;
    return false;
}

int *collect(int**matrix, int cols, int rows, int* size) {
    int *result = nullptr;
    *size = 0;
    for(int i=0; i< rows; i++) {
        for(int j=0; j<cols; j++) {
            if(hasDublingDigits(matrix[i][j])) {
                (*size)++;
                int *tmp_result = new int[*size];
                memcpy(tmp_result, result, ((*size)-1)*sizeof(int));
                tmp_result[(*size)-1]=matrix[i][j];
                result = tmp_result;
            }
        }
    }

    return result;
}

void print_arr(int* arr, int size) {
    for(int i=0; i<size; i++) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;
}

int main() {
    int rows,cols;

    std::cin >> rows >> cols;
    int **matrix = new int*[rows];
    for(int i=0;i<rows;i++) {
        matrix[i]= new int[cols];
        for(int j=0; j< cols;j++) {
            int curr;
            std::cin >> curr;
            matrix[i][j]=curr;
        }
    }

    int res_size=0;
    int *arr = collect(matrix, cols, rows, &res_size);

    print_arr(arr, res_size);
    delete arr;

    for(int i=0;i<rows;i++)
        delete matrix[i];

    delete matrix;

    return 0;
}

// 3 3 1076 1356 1918 6252 6766 5525 5524 3176 1716