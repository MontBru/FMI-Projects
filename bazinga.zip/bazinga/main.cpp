#include <iostream>

int main() {
    char* line=new char[1000];
    std::cin.getline(line, 1000);
    int chars[]={0,0,0,0,0,0};
    for(int j=0; line[j]!='\n'; j++) {
        if(line[j]=='a' || line[j]=='A')
            chars[0]++;
        else if(line[j]=='b' || line[j]=='B')
            chars[1]++;
        else if(line[j]=='z'||line[j]=='Z')
            chars[2]++;
        else if(line[j]=='i'||line[j]=='I')
            chars[3]++;
        else if(line[j]=='n'||line[j]=='N')
            chars[4]++;
        else if (line[j]=='g'||line[j]=='G')
            chars[5]++;
    }
    delete line;
    int maxwords = chars[0]/2;
    for(int i=1;i<6;i++) {
        if(chars[i]<maxwords)
            maxwords=chars[i];
    }
    std::cout << maxwords;
    return 0;
}
