#include <iostream>
using namespace std;

void toh_rec(char start, char interm, char end, int n) {
    if(n==1)
        cout<< start << "->" << end << endl;
    else {
        toh_rec(start, end, interm, n-1);
        cout<< start << "->" << end << endl;
        toh_rec(interm, start, end, n-1);
    }
}

void toh(int n) {
    toh_rec('A', 'B', 'C', n);
}

int main() {
    toh(5);
    return 0;
}