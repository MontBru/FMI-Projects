#include <iostream>

int a[1000000];
int first_sums[1000000];

int main() {
    int n=0;
    std::cin >> n;

    int first_sum_max = 0;
    int first_sum_max_ind = 0;
    int max = 0;
    {
        int i = 0;
        if(i<n) {
            std::cin >> a[0];
            first_sums[0] = a[0];
            first_sum_max = first_sums[0];
            first_sum_max_ind = 0;
            i++;
        }

        while(i<n) {
            std::cin>>a[i];
            first_sums[i] = first_sums[i-1] + a[i];
            if(first_sums[i]>first_sum_max) {
                first_sum_max = first_sums[i];
                first_sum_max_ind = i;
            }
            i++;
        }
    }

    max = first_sum_max;
    for(int i=0;i<first_sum_max_ind;i++) {
        if(first_sum_max - first_sums[i-1] > max)
            max = first_sum_max - first_sums[i-1];
    }

    std::cout << max<< std::endl;

    return 0;
}
