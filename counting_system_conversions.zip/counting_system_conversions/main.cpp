#include <cstring>
#include <iostream>

int bin_to_dec(int bin_num) {
    int dec_num = 0;
    int n = 1;
    while(bin_num) {
        dec_num += bin_num%10*n;
        bin_num/=10;
        n*=2;
    }
    return dec_num;

}

int hex_to_dec(const char* hex_num) {

    int dec_num = 0;
    size_t length = strlen(hex_num);
    int n = 1;
    for(int i=length-1; i>=0;i--) {
        if(hex_num[i]>='A' && hex_num[i]<='F')
            dec_num+=(hex_num[i]-'A'+10)*n;
        else if(hex_num[i]>='0' && hex_num[i]<='9')
            dec_num+=(hex_num[i]-'0')*n;
        else return -1;

        n*=16;
    }

    return dec_num;
}

long int dec_to_bin(int dec_num) {
    int bin = 0;
    int n = 1;
    while(dec_num) {
        bin += (dec_num%2)*n;
        dec_num/=2;
        n*=10;
    }
    return bin;
}

char* dec_to_hex(int dec_num) {
    int dec_num_cpy = dec_num;
    int arr_size = 1;
    while (dec_num_cpy) {
        dec_num_cpy/=16;
        arr_size++;
    }

    char*hex_num=new char[arr_size];
    hex_num[arr_size-1]=0;
    for(int i = 0;dec_num;i++) {
        if(dec_num%16 <=9 && dec_num%16>=0)
            hex_num[arr_size-i-2] = dec_num%16 + '0';
        else
            hex_num[arr_size-i-2]=dec_num%16 + 'A' - 10;
        dec_num/=16;
    }
    return hex_num;
}

char* bin_to_hex(int bin_num) {
    int dec_num = bin_to_dec(bin_num);
    return dec_to_hex(dec_num);
}

int hex_to_bin(char* hex_num) {
    int dec_num = hex_to_dec(hex_num);
    return dec_to_bin(dec_num);
}

int main()
{
    std::cout << bin_to_dec(1010) << std::endl;
    const char* hex_num = "EBA6F9";
    std::cout << hex_to_dec(hex_num) << std::endl;
    std::cout << dec_to_bin(234) << std::endl;
    std::cout << dec_to_hex(15443705) << std::endl;

    return 0;
}
